EN >>> You've just downloaded Bohemian Typewriter font version 1.4 (1/10/2017), made of Czech Remagg typewriter.     

Bohemian Typewriter font was created by Lukas Krakora and is free for non-commercial use only!

If you want to use this font commercially, please contact me at: krraaa@yahoo.com to get the information about pricing.

Please type "Bohemian Typewriter" in subject of your message.

I will also appreciate to receive any comments or pictures of your artwork using this font at the same address.  

Please feel free to distribute the font, but keep this readme file with it and do not change the font in any way!

Have fun! 


CZ >>> Pr�v� jste si st�hli font Bohemian Typewriter verze 1.4 (10/1/2017), vytvo�en� dle �esk�ho psac�ho stroje Remagg.

Font Bohemian Typewriter byl vytvo�en Luk�em Kr�korou a je voln� ke sta�en� a pou�it� av�ak pouze pro nekomer�n� ��ely!

V p��pad� z�m�ru vyu��t font komer�n� m� pros�m kontaktujte na emailu: krraaa@yahoo.com a dohodneme se na cen� k oboustrann� spokojenosti.

Pokud mi budete ps�t, nezapome�te do p�edm�tu zpr�vy napsat "Bohemian Typewriter".

Ocen�m i va�e koment��e nebo obr�zky va�� tvorby s vyu�it�m m�ho fontu, kter� m��ete zas�lat na stejnou adresu.

Klidn� font d�le distribuujte, ale pouze spole�n� s t�mto textem! V ��dn�m p��pad� font nijak nem��te a neupravujte.

M�jte se fajn!
